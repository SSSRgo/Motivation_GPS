# Code used in M. Zhang et al., 2024

- ROC.m
  - Matlab code used for ROC (receiver operating characteristic) analysis in M. Zhang et al., 2024.

- decoder_svm.m
  - Matlab code used for SVM decoding analysis in M. Zhang et al., 2024.
